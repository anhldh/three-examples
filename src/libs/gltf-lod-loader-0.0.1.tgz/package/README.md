GLTF LOD Loader
